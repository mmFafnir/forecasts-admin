export enum NotifyEnum {
  "EMPTY" = "Обязательное поле",
}
