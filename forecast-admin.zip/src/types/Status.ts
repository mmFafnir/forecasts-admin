export enum EnumStatus {
  LOADING = "loading",
  SUCCESS = "success",
  ERROR = "error",
  DEFAULT = "default",
}
