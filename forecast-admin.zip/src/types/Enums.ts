export enum EnumModalFilters {
  COUNTRIES = "countries",
  LEAGUES = "leagues",
  DATE = "date",
  STATUS_CHAT_GPT_TEXT = "status_chat_gbt_text",
  FAVORITE = "favorite",
}
