export type TypeSport = {
  id: number;
  name: string;
  url: string;
};
