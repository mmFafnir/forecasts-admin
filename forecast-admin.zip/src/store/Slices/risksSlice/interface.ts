export type TypeRisk = {
  created_at: "2023-11-25T14:56:12.000000Z";
  id: 1;
  name: "Low";
  updated_at: "2023-11-25T14:56:12.000000Z";
};
