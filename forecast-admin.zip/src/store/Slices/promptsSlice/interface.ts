export type TypePrompt = {
  created_at: Date | null;
  description: string;
  id: number;
  updated_at: Date | null;
};
