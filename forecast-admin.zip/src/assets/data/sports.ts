export const sports = [
  {
    label: "Футбол",
    value: "football",
    id: 1,
  },
  {
    label: "Гольф",
    value: "golf",
    id: 2,
  },
  {
    label: "Баскетбол",
    value: "basketball",
    id: 3,
  },
  {
    label: "Плавание",
    value: "swimming",
    id: 4,
  },
  {
    label: "Бокс",
    value: "boxing",
    id: 5,
  },
  {
    label: "Воллейбол",
    value: "volleyball",
    id: 6,
  },
];
