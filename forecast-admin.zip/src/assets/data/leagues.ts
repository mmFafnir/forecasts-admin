export const leagues = [
  {
    value: "1",
    label: "Лига чемпионов",
  },
  {
    value: "2",
    label: "Лига Европы",
  },
  {
    value: "3",
    label: "Евро",
  },
];
