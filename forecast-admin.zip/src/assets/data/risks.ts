export const risks = [
  {
    value: "Минимальный",
    label: "Минимальный",
  },
  {
    value: "Низкий",
    label: "Низкий",
  },
  {
    value: "Средний",
    label: "Средний",
  },
  {
    value: "Высокий",
    label: "Высокий",
  },
  {
    value: "Экстремальный",
    label: "Экстремальный",
  },
];
