const UserElementPage = () => {
  return <div></div>;
};

export default UserElementPage;
